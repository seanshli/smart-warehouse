-- AlterTable
ALTER TABLE "items" ADD COLUMN "buyCost" REAL;
ALTER TABLE "items" ADD COLUMN "buyDate" DATETIME;
ALTER TABLE "items" ADD COLUMN "buyLocation" TEXT;
ALTER TABLE "items" ADD COLUMN "invoiceNumber" TEXT;
ALTER TABLE "items" ADD COLUMN "sellerName" TEXT;
