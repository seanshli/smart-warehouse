package com.midea.oem.sdk.demo

import android.util.Log
import androidx.multidex.MultiDexApplication
import com.midea.oem.iot.core.http.OKHttpManager
import com.midea.oem.iot.sdk.account.OEMAccountManager
import com.midea.oem.iot.sdk.device.OEMDeviceManager
import org.json.JSONObject
import java.io.File
import java.util.*
import kotlin.system.measureTimeMillis

class MyApplication : MultiDexApplication() {

    override fun onCreate() {
        super.onCreate()

        OKHttpManager.init(
            enableDebugLog = true,
            appSecret = "签名算法用到, 由OEM统一分配",
            appKey = "签名算法用到, 由OEM统一分配",
            encryptKey = "加密key, 由OEM统一分配",
            userAgents = "Http 请求的user-agent",
            appId = "AppID, 由OEM统一分配",
            environment = "环境信息，可选传入：dev-, sit-, uat- ,空",
            domain = "域名，默认为us.dollin.net，可以通过获取地区接口更新"
        )

        OEMAccountManager.init(this)
        OEMDeviceManager.init("M-Smart协议ClientID", "M-Smart协议ClientSecret")
    }
}